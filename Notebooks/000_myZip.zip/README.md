--------------------------------------------------------------------------------
EXPERIMENT 101
--------------------------------------------------------------------------------
Metadata:
	Plate id: 1
	Plate location: 1D
	Initial pH: 1.0
	Initial temperature: 1.0

Perturbation 0
--------------------------------------------------------------------------------
Files:
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/1/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/2/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/3/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/4/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/5/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/6/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/7/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/8/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/9/abundance_file.txt

Perturbation 101.1
--------------------------------------------------------------------------------
Metadata:
	Property perturbed: pH
	New value: 7
	Starting time (minutes): 0
	Ending time (minutes): 20
Files:
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/5/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/4/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/3/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/2/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/1/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/6/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/7/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/8/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/101/101.1/9/abundance_file.txt



--------------------------------------------------------------------------------
EXPERIMENT 102
--------------------------------------------------------------------------------
Metadata:
	Plate id: 1
	Plate location: 1A
	Initial pH: 5.0
	Initial temperature: 5.0

Perturbation 0
--------------------------------------------------------------------------------
Files:
	/Users/julia/bacterialGrowth_thesis/Data/experiments/102/1/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/102/2/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/102/3/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/102/4/abundance_file.txt
	/Users/julia/bacterialGrowth_thesis/Data/experiments/102/5/abundance_file.txt



